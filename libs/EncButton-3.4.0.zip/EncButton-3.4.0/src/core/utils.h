#include <Arduino.h>

#define EB_UPTIME() millis()

bool EBread(const uint8_t pin);